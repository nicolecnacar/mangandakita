# HOW TO RUN
1. npm init -y
2. npm install express express-session body-parser cookie-parser mysql ejs
3. start xampp
4. open folder in terminal
5. run node app.js
6. go to localhost:3000